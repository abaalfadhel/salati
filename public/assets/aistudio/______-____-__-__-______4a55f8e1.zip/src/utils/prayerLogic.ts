import { PrayerBalances, PrayerRecord, PrayerType, AppData } from '../types';

export const STANDARD_RAKATS: Record<PrayerType, number> = {
  fajr: 2,
  dhuhr: 4,
  asr: 4,
  maghrib: 3,
  isha: 4,
};

export const PRAYER_NAMES: Record<PrayerType, string> = {
  fajr: 'الفجر',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

export const PRAYER_ORDER: PrayerType[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

export function generateGuestId(): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  let segment1 = '';
  let segment2 = '';
  for (let i = 0; i < 4; i++) {
    segment1 += chars.charAt(Math.floor(Math.random() * chars.length));
    segment2 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `GST-${segment1}-${segment2}`;
}

export function estimateBalancesFromYearsAndMonths(years: number, months: number): PrayerBalances {
  const validYears = Math.max(0, Math.floor(Number(years) || 0));
  const validMonths = Math.max(0, Math.floor(Number(months) || 0));
  const totalDays = validYears * 365 + validMonths * 30;

  return {
    fajr: totalDays,
    dhuhr: totalDays,
    asr: totalDays,
    maghrib: totalDays,
    isha: totalDays,
  };
}

export function calculateTotalPrayers(balances: PrayerBalances): number {
  return (
    (balances.fajr || 0) +
    (balances.dhuhr || 0) +
    (balances.asr || 0) +
    (balances.maghrib || 0) +
    (balances.isha || 0)
  );
}

export function calculateTotalRakats(balances: PrayerBalances): number {
  return (
    (balances.fajr || 0) * STANDARD_RAKATS.fajr +
    (balances.dhuhr || 0) * STANDARD_RAKATS.dhuhr +
    (balances.asr || 0) * STANDARD_RAKATS.asr +
    (balances.maghrib || 0) * STANDARD_RAKATS.maghrib +
    (balances.isha || 0) * STANDARD_RAKATS.isha
  );
}

export function calculateCompletionPercentage(startingTotal: number, completedTotal: number): number {
  if (!startingTotal || startingTotal <= 0) {
    return completedTotal > 0 ? 100 : 0;
  }
  const pct = (completedTotal / startingTotal) * 100;
  return Math.min(100, Math.max(0, Math.round(pct * 10) / 10));
}

export function recordPrayerCompletion(
  currentRemaining: PrayerBalances,
  currentCompleted: PrayerBalances,
  prayer: PrayerType,
  quantity: number,
  note?: string,
  customDate?: string
): {
  success: boolean;
  error?: string;
  newRemaining: PrayerBalances;
  newCompleted: PrayerBalances;
  record?: PrayerRecord;
} {
  const count = Math.floor(Number(quantity));
  if (count <= 0) {
    return {
      success: false,
      error: 'يرجى إدخال عدد صحيح أكبر من صفر',
      newRemaining: { ...currentRemaining },
      newCompleted: { ...currentCompleted },
    };
  }

  const remaining = currentRemaining[prayer] || 0;
  if (count > remaining) {
    return {
      success: false,
      error: `العدد المدخل (${count}) يتجاوز الرصيد المتبقي لصلاة ${PRAYER_NAMES[prayer]} وهو (${remaining})`,
      newRemaining: { ...currentRemaining },
      newCompleted: { ...currentCompleted },
    };
  }

  const newRemaining: PrayerBalances = {
    ...currentRemaining,
    [prayer]: remaining - count,
  };

  const newCompleted: PrayerBalances = {
    ...currentCompleted,
    [prayer]: (currentCompleted[prayer] || 0) + count,
  };

  const todayStr = customDate || new Date().toISOString().split('T')[0];
  const rakats = count * STANDARD_RAKATS[prayer];

  const record: PrayerRecord = {
    id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    prayer,
    quantity: count,
    rakats,
    date: todayStr,
    timestamp: Date.now(),
    note: note ? note.trim().slice(0, 200) : undefined,
  };

  return {
    success: true,
    newRemaining,
    newCompleted,
    record,
  };
}

export function undoPrayerCompletion(
  currentRemaining: PrayerBalances,
  currentCompleted: PrayerBalances,
  record: PrayerRecord
): {
  newRemaining: PrayerBalances;
  newCompleted: PrayerBalances;
} {
  const prayer = record.prayer;
  const count = record.quantity;

  const newRemaining: PrayerBalances = {
    ...currentRemaining,
    [prayer]: (currentRemaining[prayer] || 0) + count,
  };

  const newCompleted: PrayerBalances = {
    ...currentCompleted,
    [prayer]: Math.max(0, (currentCompleted[prayer] || 0) - count),
  };

  return {
    newRemaining,
    newCompleted,
  };
}

export function getNextSequentialPrayer(remaining: PrayerBalances): PrayerType | null {
  for (const prayer of PRAYER_ORDER) {
    if ((remaining[prayer] || 0) > 0) {
      return prayer;
    }
  }
  return null;
}

export function getArabicFormattedDate(date: Date = new Date()): string {
  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  };
  return date.toLocaleDateString('ar-SA-u-ca-gregory', options);
}

export function validateBackupData(data: any): { valid: boolean; error?: string; parsed?: AppData } {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'الملف لا يحتوي على كائن بيانات صالح' };
  }

  if (typeof data.schemaVersion !== 'number' || data.schemaVersion < 1) {
    return { valid: false, error: 'إصدار المخطط غير مدعوم أو غير صالح' };
  }

  if (!data.profile || typeof data.profile.displayName !== 'string' || !data.profile.guestId) {
    return { valid: false, error: 'بيانات الملف التعريفي غير مكتملة' };
  }

  const prayers: PrayerType[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  for (const p of prayers) {
    if (
      !data.startingBalances ||
      typeof data.startingBalances[p] !== 'number' ||
      data.startingBalances[p] < 0
    ) {
      return { valid: false, error: `الرصيد الابتدائي لصلاة ${PRAYER_NAMES[p]} غير صالح` };
    }
    if (
      !data.remainingBalances ||
      typeof data.remainingBalances[p] !== 'number' ||
      data.remainingBalances[p] < 0
    ) {
      return { valid: false, error: `الرصيد المتبقي لصلاة ${PRAYER_NAMES[p]} غير صالح` };
    }
    if (
      !data.completedTotals ||
      typeof data.completedTotals[p] !== 'number' ||
      data.completedTotals[p] < 0
    ) {
      return { valid: false, error: `الرصيد المنجز لصلاة ${PRAYER_NAMES[p]} غير صالح` };
    }
  }

  if (!Array.isArray(data.history)) {
    return { valid: false, error: 'سجل العمليات غير صالح' };
  }

  // Ensure sanitization: prevent raw injection
  const sanitizedProfile = {
    guestId: String(data.profile.guestId).replace(/[^\w-]/g, '').slice(0, 30),
    displayName: String(data.profile.displayName).replace(/[<>]/g, '').slice(0, 60),
    nickname: data.profile.nickname ? String(data.profile.nickname).replace(/[<>]/g, '').slice(0, 60) : undefined,
    createdAt: String(data.profile.createdAt || new Date().toISOString()),
  };

  const parsed: AppData = {
    schemaVersion: data.schemaVersion,
    isOnboarded: Boolean(data.isOnboarded),
    profile: sanitizedProfile,
    startingBalances: {
      fajr: Number(data.startingBalances.fajr),
      dhuhr: Number(data.startingBalances.dhuhr),
      asr: Number(data.startingBalances.asr),
      maghrib: Number(data.startingBalances.maghrib),
      isha: Number(data.startingBalances.isha),
    },
    remainingBalances: {
      fajr: Number(data.remainingBalances.fajr),
      dhuhr: Number(data.remainingBalances.dhuhr),
      asr: Number(data.remainingBalances.asr),
      maghrib: Number(data.remainingBalances.maghrib),
      isha: Number(data.remainingBalances.isha),
    },
    completedTotals: {
      fajr: Number(data.completedTotals.fajr),
      dhuhr: Number(data.completedTotals.dhuhr),
      asr: Number(data.completedTotals.asr),
      maghrib: Number(data.completedTotals.maghrib),
      isha: Number(data.completedTotals.isha),
    },
    history: data.history.map((h: any) => ({
      id: String(h.id || ''),
      prayer: prayers.includes(h.prayer) ? h.prayer : 'fajr',
      quantity: Math.max(1, Math.floor(Number(h.quantity) || 1)),
      rakats: Math.max(1, Math.floor(Number(h.rakats) || 1)),
      date: String(h.date || ''),
      timestamp: Number(h.timestamp) || Date.now(),
      note: h.note ? String(h.note).replace(/[<>]/g, '').slice(0, 200) : undefined,
    })),
    dailySessions: typeof data.dailySessions === 'object' && data.dailySessions !== null ? data.dailySessions : {},
    activePlan: data.activePlan || {
      mode: 'daily_total',
      dailyTotal: 5,
      distribution: { fajr: 1, dhuhr: 1, asr: 1, maghrib: 1, isha: 1 },
    },
    achievements: Array.isArray(data.achievements) ? data.achievements : [],
    challenges: Array.isArray(data.challenges) ? data.challenges : [],
    settings: data.settings || {
      theme: 'light',
      includeGuestIdOnCertificate: true,
      notificationsEnabled: false,
    },
  };

  return { valid: true, parsed };
}
