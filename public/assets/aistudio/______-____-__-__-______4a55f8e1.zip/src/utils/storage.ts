import { AppData, UserProfile } from '../types';
import { generateGuestId, validateBackupData } from './prayerLogic';
import { INITIAL_ACHIEVEMENTS } from './achievementsList';

const DB_NAME = 'salati_db';
const DB_VERSION = 1;
const STORE_NAME = 'app_state';
const STATE_KEY = 'current_app_data';
const LOCAL_STORAGE_FALLBACK_KEY = 'salati_app_data_backup';

export function getDefaultAppData(): AppData {
  const guestId = generateGuestId();
  const profile: UserProfile = {
    guestId,
    displayName: 'ضيف كريم',
    nickname: '',
    createdAt: new Date().toISOString(),
  };

  return {
    schemaVersion: 1,
    isOnboarded: false,
    profile,
    startingBalances: {
      fajr: 0,
      dhuhr: 0,
      asr: 0,
      maghrib: 0,
      isha: 0,
    },
    remainingBalances: {
      fajr: 0,
      dhuhr: 0,
      asr: 0,
      maghrib: 0,
      isha: 0,
    },
    completedTotals: {
      fajr: 0,
      dhuhr: 0,
      asr: 0,
      maghrib: 0,
      isha: 0,
    },
    history: [],
    dailySessions: {},
    activePlan: {
      mode: 'daily_total',
      dailyTotal: 5,
      distribution: {
        fajr: 1,
        dhuhr: 1,
        asr: 1,
        maghrib: 1,
        isha: 1,
      },
    },
    achievements: INITIAL_ACHIEVEMENTS,
    challenges: [
      {
        id: 'daily_5',
        type: 'daily',
        title: 'تحدي اليوم المبارك',
        description: 'إنجاز 5 صلوات قضاء خلال هذا اليوم المبارك',
        target: 5,
        completed: 0,
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date().toISOString().split('T')[0],
        reward: 'وسام اليوم المبارك',
        isCompleted: false,
      },
      {
        id: 'weekly_35',
        type: 'weekly',
        title: 'تحدي الأسبوع الثابت',
        description: 'إنجاز 35 صلاة قضاء خلال أسبوع متواصل',
        target: 35,
        completed: 0,
        startDate: new Date().toISOString().split('T')[0],
        endDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
        reward: 'شارة الهمة الأسبوعية',
        isCompleted: false,
      },
    ],
    settings: {
      theme: 'light',
      includeGuestIdOnCertificate: true,
      notificationsEnabled: false,
    },
  };
}

// Open IndexedDB database with Promise wrapper
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB غير مدعوم في هذا المتصفح'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function loadAppData(): Promise<AppData> {
  let loadedData: AppData | null = null;

  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const getReq = store.get(STATE_KEY);

    loadedData = await new Promise<AppData | null>((resolve) => {
      getReq.onsuccess = () => resolve(getReq.result || null);
      getReq.onerror = () => resolve(null);
    });
  } catch (err) {
    console.warn('تعذر القراءة من IndexedDB، جاري المحاولة من التخزين المحلي:', err);
  }

  // If not found in IndexedDB, try localStorage
  if (!loadedData && typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(LOCAL_STORAGE_FALLBACK_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const validated = validateBackupData(parsed);
        if (validated.valid && validated.parsed) {
          loadedData = validated.parsed;
        }
      }
    } catch (e) {
      console.warn('خطأ في استرجاع النسخة الاحتياطية من التخزين المحلي', e);
    }
  }

  if (!loadedData) {
    const freshDefault = getDefaultAppData();
    await saveAppData(freshDefault);
    return freshDefault;
  }

  // Ensure any newly added achievements exist
  if (!loadedData.achievements || loadedData.achievements.length < INITIAL_ACHIEVEMENTS.length) {
    const existingIds = new Set((loadedData.achievements || []).map((a) => a.id));
    const mergedAchievements = [...(loadedData.achievements || [])];
    for (const initAch of INITIAL_ACHIEVEMENTS) {
      if (!existingIds.has(initAch.id)) {
        mergedAchievements.push(initAch);
      }
    }
    loadedData.achievements = mergedAchievements;
  }

  return loadedData;
}

export async function saveAppData(data: AppData): Promise<void> {
  // Mirror to LocalStorage first for high-speed redundancy
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(LOCAL_STORAGE_FALLBACK_KEY, JSON.stringify(data));
      localStorage.setItem('salati_theme', data.settings.theme);
    } catch (e) {
      console.warn('تعذر الحفظ في localStorage:', e);
    }
  }

  // Save to IndexedDB
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(data, STATE_KEY);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('تعذر الحفظ في IndexedDB:', err);
  }
}

export function exportAppDataAsJson(data: AppData): string {
  return JSON.stringify(data, null, 2);
}

export function importAppDataFromJson(jsonStr: string): { success: boolean; data?: AppData; error?: string } {
  try {
    if (!jsonStr || jsonStr.trim().length === 0) {
      return { success: false, error: 'الملف فارغ' };
    }
    if (jsonStr.length > 5 * 1024 * 1024) {
      return { success: false, error: 'حجم الملف يتجاوز الحد المسموح (5 ميجابايت)' };
    }

    const parsed = JSON.parse(jsonStr);
    const result = validateBackupData(parsed);

    if (!result.valid || !result.parsed) {
      return { success: false, error: result.error || 'صيغة البيانات غير صحيحة' };
    }

    return { success: true, data: result.parsed };
  } catch (err: any) {
    return { success: false, error: 'تعذر قراءة ملف JSON: تأكد من سلامة الملف' };
  }
}

export async function clearAllLocalData(): Promise<void> {
  if (typeof window !== 'undefined') {
    try {
      localStorage.removeItem(LOCAL_STORAGE_FALLBACK_KEY);
      localStorage.removeItem('salati_theme');
    } catch (e) {
      console.error(e);
    }
  }

  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    await new Promise<void>((resolve) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch (e) {
    console.error(e);
  }
}
