import test from 'node:test';
import assert from 'node:assert/strict';
import {
  STANDARD_RAKATS,
  estimateBalancesFromYearsAndMonths,
  calculateTotalPrayers,
  calculateTotalRakats,
  calculateCompletionPercentage,
  recordPrayerCompletion,
  undoPrayerCompletion,
  getNextSequentialPrayer,
  validateBackupData,
  generateGuestId,
} from './prayerLogic';
import { PrayerBalances } from '../types';

test('Guest ID generation returns valid GST format', () => {
  const id = generateGuestId();
  assert.match(id, /^GST-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
});

test('estimateBalancesFromYearsAndMonths calculates correctly', () => {
  // 1 year (365 days) + 2 months (60 days) = 425 days per prayer
  const balances = estimateBalancesFromYearsAndMonths(1, 2);
  assert.equal(balances.fajr, 425);
  assert.equal(balances.dhuhr, 425);
  assert.equal(balances.asr, 425);
  assert.equal(balances.maghrib, 425);
  assert.equal(balances.isha, 425);

  const totalPrayers = calculateTotalPrayers(balances);
  assert.equal(totalPrayers, 425 * 5); // 2125 prayers

  // Rakats: 425*(2+4+4+3+4) = 425*17 = 7225
  const totalRakats = calculateTotalRakats(balances);
  assert.equal(totalRakats, 425 * 17);
});

test('calculateCompletionPercentage handles 0 and normal bounds', () => {
  assert.equal(calculateCompletionPercentage(0, 0), 0);
  assert.equal(calculateCompletionPercentage(100, 25), 25);
  assert.equal(calculateCompletionPercentage(100, 100), 100);
  assert.equal(calculateCompletionPercentage(300, 100), 33.3);
  assert.equal(calculateCompletionPercentage(100, 120), 100); // capped at 100
});

test('recordPrayerCompletion deducts remaining and increments completed', () => {
  const currentRemaining: PrayerBalances = {
    fajr: 10,
    dhuhr: 10,
    asr: 10,
    maghrib: 10,
    isha: 10,
  };
  const currentCompleted: PrayerBalances = {
    fajr: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  };

  const result = recordPrayerCompletion(currentRemaining, currentCompleted, 'fajr', 3, 'قضاء بعد الفجر');
  assert.equal(result.success, true);
  assert.equal(result.newRemaining.fajr, 7);
  assert.equal(result.newCompleted.fajr, 3);
  assert.equal(result.record?.rakats, 3 * STANDARD_RAKATS.fajr); // 6
  assert.equal(result.record?.note, 'قضاء بعد الفجر');

  // Prevent exceeding remaining
  const failResult = recordPrayerCompletion(result.newRemaining, result.newCompleted, 'fajr', 10);
  assert.equal(failResult.success, false);
  assert.equal(failResult.newRemaining.fajr, 7); // unchanged
});

test('undoPrayerCompletion safely restores balances', () => {
  const currentRemaining: PrayerBalances = { fajr: 7, dhuhr: 10, asr: 10, maghrib: 10, isha: 10 };
  const currentCompleted: PrayerBalances = { fajr: 3, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };

  const record = {
    id: 'test_rec',
    prayer: 'fajr' as const,
    quantity: 3,
    rakats: 6,
    date: '2026-10-22',
    timestamp: Date.now(),
  };

  const undone = undoPrayerCompletion(currentRemaining, currentCompleted, record);
  assert.equal(undone.newRemaining.fajr, 10);
  assert.equal(undone.newCompleted.fajr, 0);
});

test('getNextSequentialPrayer finds first unfinished prayer', () => {
  const balances: PrayerBalances = { fajr: 0, dhuhr: 5, asr: 10, maghrib: 0, isha: 0 };
  assert.equal(getNextSequentialPrayer(balances), 'dhuhr');

  const emptyBalances: PrayerBalances = { fajr: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 };
  assert.equal(getNextSequentialPrayer(emptyBalances), null);
});

test('validateBackupData detects invalid payloads and sanitizes valid ones', () => {
  const invalidResult = validateBackupData({ foo: 'bar' });
  assert.equal(invalidResult.valid, false);

  const validSample = {
    schemaVersion: 1,
    isOnboarded: true,
    profile: {
      guestId: 'GST-1234-5678',
      displayName: 'محمد',
      createdAt: '2026-01-01T00:00:00.000Z',
    },
    startingBalances: { fajr: 10, dhuhr: 10, asr: 10, maghrib: 10, isha: 10 },
    remainingBalances: { fajr: 5, dhuhr: 10, asr: 10, maghrib: 10, isha: 10 },
    completedTotals: { fajr: 5, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
    history: [],
  };

  const validResult = validateBackupData(validSample);
  assert.equal(validResult.valid, true);
  assert.equal(validResult.parsed?.profile.displayName, 'محمد');
  assert.equal(validResult.parsed?.remainingBalances.fajr, 5);
});
