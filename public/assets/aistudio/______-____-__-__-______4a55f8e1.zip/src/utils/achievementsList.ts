import { Achievement, AppData, PrayerBalances } from '../types';
import { calculateCompletionPercentage, calculateTotalPrayers } from './prayerLogic';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_prayer',
    title: 'أول خطوة في طريق القضاء',
    description: 'تسجيل أول صلاة قضاء في التطبيق.',
    icon: 'Sparkles',
    requirement: 'تسجيل صلاة واحدة على الأقل',
    progress: 0,
    maxProgress: 1,
    unlocked: false,
  },
  {
    id: 'ten_prayers',
    title: 'بداية الهمة (10 صلوات)',
    description: 'إنجاز 10 صلوات قضاء بنجاح.',
    icon: 'Flame',
    requirement: 'إنجاز 10 صلوات قضاء',
    progress: 0,
    maxProgress: 10,
    unlocked: false,
  },
  {
    id: 'fifty_prayers',
    title: 'خطى واثقة (50 صلاة)',
    description: 'إنجاز 50 صلاة قضاء موثقة.',
    icon: 'ShieldCheck',
    requirement: 'إنجاز 50 صلاة قضاء',
    progress: 0,
    maxProgress: 50,
    unlocked: false,
  },
  {
    id: 'hundred_prayers',
    title: 'مئة من النور (100 صلاة)',
    description: 'إنجاز 100 صلاة قضاء، مبارك هذا العزم.',
    icon: 'Award',
    requirement: 'إنجاز 100 صلاة قضاء',
    progress: 0,
    maxProgress: 100,
    unlocked: false,
  },
  {
    id: 'five_hundred_prayers',
    title: 'صاحب العزم المتين (500 صلاة)',
    description: 'إنجاز 500 صلاة قضاء في ميزان حسناتك.',
    icon: 'Crown',
    requirement: 'إنجاز 500 صلاة قضاء',
    progress: 0,
    maxProgress: 500,
    unlocked: false,
  },
  {
    id: 'thousand_prayers',
    title: 'ألفية الوفاء (1,000 صلاة)',
    description: 'إنجاز ألف صلاة قضاء، هنيئاً لك هذا الثبات.',
    icon: 'Star',
    requirement: 'إنجاز 1,000 صلاة قضاء',
    progress: 0,
    maxProgress: 1000,
    unlocked: false,
  },
  {
    id: 'daily_goal_done',
    title: 'وفاء بالعهد اليومي',
    description: 'إكمال هدف اليوم بالكامل بنجاح.',
    icon: 'CheckCircle2',
    requirement: 'إكمال كامل الهدف المحدد ليوم واحد',
    progress: 0,
    maxProgress: 1,
    unlocked: false,
  },
  {
    id: 'streak_7_days',
    title: 'أسبوع من الاستقامة',
    description: 'المحافظة على تسجيل القضاء لمدة 7 أيام متتالية أو متتابعة الجلسات.',
    icon: 'CalendarDays',
    requirement: 'تسجيل القضاء في 7 أيام مختلفة',
    progress: 0,
    maxProgress: 7,
    unlocked: false,
  },
  {
    id: 'quarter_done',
    title: 'ربع المسير (25%)',
    description: 'إنجاز 25% من إجمالي الرصيد المسجل.',
    icon: 'TrendingUp',
    requirement: 'الوصول إلى نسبة إنجاز 25%',
    progress: 0,
    maxProgress: 25,
    unlocked: false,
  },
  {
    id: 'half_done',
    title: 'منتصف الطريق (50%)',
    description: 'إنجاز نصف الصلوات الفائتة المسجلة.',
    icon: 'Compass',
    requirement: 'الوصول إلى نسبة إنجاز 50%',
    progress: 0,
    maxProgress: 50,
    unlocked: false,
  },
  {
    id: 'three_quarters_done',
    title: 'اقتراب الأمل (75%)',
    description: 'إنجاز ثلاثة أرباع الصلوات المسجلة.',
    icon: 'Medal',
    requirement: 'الوصول إلى نسبة إنجاز 75%',
    progress: 0,
    maxProgress: 75,
    unlocked: false,
  },
  {
    id: 'full_completion',
    title: 'براءة الذمة التامة (100%)',
    description: 'إتمام جميع الصلوات الفائتة المسجلة واستحقاق الشهادة.',
    icon: 'Trophy',
    requirement: 'تصفير رصيد جميع الصلوات الخمس بنسبة 100%',
    progress: 0,
    maxProgress: 100,
    unlocked: false,
  },
  {
    id: 'fajr_focus',
    title: 'فرسان الفجر',
    description: 'قضاء 20 صلاة فجر بنجاح.',
    icon: 'Sun',
    requirement: 'إنجاز 20 صلاة فجر',
    progress: 0,
    maxProgress: 20,
    unlocked: false,
  },
];

export function evaluateAchievements(appData: AppData): {
  updatedAchievements: Achievement[];
  newlyUnlocked: Achievement[];
} {
  const completedTotal = calculateTotalPrayers(appData.completedTotals);
  const startingTotal = calculateTotalPrayers(appData.startingBalances);
  const remainingTotal = calculateTotalPrayers(appData.remainingBalances);
  const completionPct = calculateCompletionPercentage(startingTotal, completedTotal);

  // Calculate distinct recorded days
  const recordedDates = new Set(appData.history.map((h) => h.date));
  const distinctDaysCount = recordedDates.size;

  // Check if any daily session hit target
  let hasCompletedDailyGoal = false;
  for (const date in appData.dailySessions) {
    const s = appData.dailySessions[date];
    if (s.target > 0 && s.completed >= s.target) {
      hasCompletedDailyGoal = true;
      break;
    }
  }

  const existingAchievements = appData.achievements.length > 0 ? appData.achievements : INITIAL_ACHIEVEMENTS;
  const newlyUnlocked: Achievement[] = [];

  const updatedAchievements = existingAchievements.map((ach) => {
    // If already unlocked, preserve unlocked date
    if (ach.unlocked) return ach;

    let progress = 0;
    let unlocked = false;

    switch (ach.id) {
      case 'first_prayer':
        progress = Math.min(1, completedTotal);
        unlocked = completedTotal >= 1;
        break;
      case 'ten_prayers':
        progress = Math.min(10, completedTotal);
        unlocked = completedTotal >= 10;
        break;
      case 'fifty_prayers':
        progress = Math.min(50, completedTotal);
        unlocked = completedTotal >= 50;
        break;
      case 'hundred_prayers':
        progress = Math.min(100, completedTotal);
        unlocked = completedTotal >= 100;
        break;
      case 'five_hundred_prayers':
        progress = Math.min(500, completedTotal);
        unlocked = completedTotal >= 500;
        break;
      case 'thousand_prayers':
        progress = Math.min(1000, completedTotal);
        unlocked = completedTotal >= 1000;
        break;
      case 'daily_goal_done':
        progress = hasCompletedDailyGoal ? 1 : 0;
        unlocked = hasCompletedDailyGoal;
        break;
      case 'streak_7_days':
        progress = Math.min(7, distinctDaysCount);
        unlocked = distinctDaysCount >= 7;
        break;
      case 'quarter_done':
        progress = Math.min(25, completionPct);
        unlocked = completionPct >= 25 && startingTotal > 0;
        break;
      case 'half_done':
        progress = Math.min(50, completionPct);
        unlocked = completionPct >= 50 && startingTotal > 0;
        break;
      case 'three_quarters_done':
        progress = Math.min(75, completionPct);
        unlocked = completionPct >= 75 && startingTotal > 0;
        break;
      case 'full_completion':
        progress = Math.min(100, completionPct);
        unlocked = remainingTotal === 0 && startingTotal > 0 && completedTotal >= startingTotal;
        break;
      case 'fajr_focus':
        progress = Math.min(20, appData.completedTotals.fajr || 0);
        unlocked = (appData.completedTotals.fajr || 0) >= 20;
        break;
      default:
        break;
    }

    if (unlocked && !ach.unlocked) {
      const unlockedAch: Achievement = {
        ...ach,
        progress: ach.maxProgress,
        unlocked: true,
        unlockedAt: new Date().toISOString(),
      };
      newlyUnlocked.push(unlockedAch);
      return unlockedAch;
    }

    return {
      ...ach,
      progress,
    };
  });

  return {
    updatedAchievements,
    newlyUnlocked,
  };
}

export function calculateUserLevel(completedTotal: number): {
  levelNumber: number;
  levelName: string;
  nextThreshold: number;
  progressToNext: number;
} {
  const levels = [
    { level: 1, name: 'مبتدئ العزم', max: 20 },
    { level: 2, name: 'الساعي للوفاء', max: 50 },
    { level: 3, name: 'المجتهد الصادق', max: 150 },
    { level: 4, name: 'المثابر الثابت', max: 350 },
    { level: 5, name: 'صاحب الهمة العالية', max: 700 },
    { level: 6, name: 'فارس القضاء', max: 1500 },
    { level: 7, name: 'الواصل لصفاء الذمة', max: 3000 },
    { level: 8, name: 'المتم للميثاق', max: 100000 },
  ];

  let current = levels[0];
  let prevMax = 0;

  for (let i = 0; i < levels.length; i++) {
    if (completedTotal < levels[i].max) {
      current = levels[i];
      prevMax = i > 0 ? levels[i - 1].max : 0;
      break;
    }
    if (i === levels.length - 1) {
      current = levels[i];
      prevMax = levels[i - 1].max;
    }
  }

  const range = current.max - prevMax;
  const inLevel = Math.max(0, completedTotal - prevMax);
  const progressToNext = Math.min(100, Math.round((inLevel / range) * 100));

  return {
    levelNumber: current.level,
    levelName: current.name,
    nextThreshold: current.max,
    progressToNext,
  };
}
