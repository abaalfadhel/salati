import React from 'react';
import { Plus, Check, Sparkles } from 'lucide-react';
import { PrayerType } from '../types';
import { PRAYER_NAMES, STANDARD_RAKATS } from '../utils/prayerLogic';

interface Props {
  prayer: PrayerType;
  remainingCount: number;
  completedCount: number;
  dailyTarget: number;
  todayCompleted: number;
  onOpenRecordModal: (prayer: PrayerType) => void;
  isNextSequential?: boolean;
}

export const PrayerCard: React.FC<Props> = ({
  prayer,
  remainingCount,
  completedCount,
  dailyTarget,
  todayCompleted,
  onOpenRecordModal,
  isNextSequential = false,
}) => {
  const name = PRAYER_NAMES[prayer];
  const rakatsPerPrayer = STANDARD_RAKATS[prayer];
  const remainingRakats = remainingCount * rakatsPerPrayer;
  const initialEstimate = remainingCount + completedCount;
  const progressPercent =
    initialEstimate > 0 ? Math.min(100, Math.round((completedCount / initialEstimate) * 100)) : 0;
  const isAllCleared = remainingCount === 0;

  return (
    <div
      className={`relative bg-white dark:bg-stone-900 border rounded-2xl p-4 shadow-xs transition-all hover:shadow-md ${
        isNextSequential
          ? 'border-amber-400 dark:border-amber-500 ring-2 ring-amber-400/20'
          : isAllCleared
          ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50/30 dark:bg-emerald-950/20'
          : 'border-stone-200 dark:border-stone-800'
      }`}
    >
      {/* Badge if it is next sequential */}
      {isNextSequential && (
        <span className="absolute -top-2.5 right-4 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 text-[10px] font-bold shadow-xs flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          <span>الدور التالي في القضاء</span>
        </span>
      )}

      {/* Top Header of Card */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
              isAllCleared
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
            }`}
          >
            {isAllCleared ? <Check className="w-4 h-4" /> : rakatsPerPrayer}
          </div>
          <div>
            <h4 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-tajawal">
              صلاة {name}
            </h4>
            <p className="text-[10px] text-stone-500 dark:text-stone-400">
              {rakatsPerPrayer} ركعات مفروضة
            </p>
          </div>
        </div>

        <button
          onClick={() => onOpenRecordModal(prayer)}
          disabled={isAllCleared}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer active:scale-95 ${
            isAllCleared
              ? 'bg-stone-100 dark:bg-stone-800 text-stone-400 cursor-not-allowed'
              : 'bg-emerald-800 hover:bg-emerald-700 text-amber-200 border border-amber-400/30'
          }`}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>تسجيل إنجاز</span>
        </button>
      </div>

      {/* Key Counts Grid */}
      <div className="grid grid-cols-2 gap-2 text-xs mb-3">
        <div className="p-2 rounded-xl bg-stone-50 dark:bg-stone-800/50">
          <span className="text-[10px] text-stone-500 dark:text-stone-400 block mb-0.5">
            المتبقي في الذمة:
          </span>
          <div className="flex items-baseline gap-1">
            <span
              className={`text-sm font-black ${
                isAllCleared
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-amber-700 dark:text-amber-400'
              }`}
            >
              {remainingCount.toLocaleString('ar-SA')}
            </span>
            <span className="text-[10px] text-stone-400">صلاة</span>
          </div>
          <span className="text-[10px] text-stone-500 dark:text-stone-400 block">
            ما يقارب {remainingRakats.toLocaleString('ar-SA')} ركعة
          </span>
        </div>

        <div className="p-2 rounded-xl bg-stone-50 dark:bg-stone-800/50">
          <span className="text-[10px] text-stone-500 dark:text-stone-400 block mb-0.5">
            المنجز بفضل الله:
          </span>
          <div className="flex items-baseline gap-1">
            <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">
              {completedCount.toLocaleString('ar-SA')}
            </span>
            <span className="text-[10px] text-stone-400">صلاة</span>
          </div>
          <span className="text-[10px] text-stone-500 dark:text-stone-400 block">
            اليوم: <span className="font-bold text-stone-800 dark:text-stone-200">{todayCompleted}</span> / {dailyTarget}
          </span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="flex items-center justify-between text-[10px] text-stone-500 dark:text-stone-400 mb-1">
        <span>نسبة الإنجاز: {progressPercent}%</span>
        {isAllCleared && <span className="text-emerald-600 font-bold">تم إبراء الذمة بالكامل! 🎉</span>}
      </div>
      <div className="w-full bg-stone-200 dark:bg-stone-800 h-1.5 rounded-full overflow-hidden">
        <div
          className="bg-emerald-600 dark:bg-emerald-500 h-full rounded-full transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>
    </div>
  );
};
