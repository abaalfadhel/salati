import React, { useRef, useState } from 'react';
import {
  Award,
  Download,
  Printer,
  Sparkles,
  ShieldCheck,
  Eye,
  CheckCircle2,
  Lock,
  Share2,
} from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { AppData, PrayerBalances } from '../types';
import {
  calculateTotalPrayers,
  calculateTotalRakats,
  getArabicFormattedDate,
  PRAYER_NAMES,
  STANDARD_RAKATS,
} from '../utils/prayerLogic';

interface Props {
  appData: AppData;
  onUpdateSettings: (newSettings: any) => void;
}

export const CertificateGallery: React.FC<Props> = ({ appData, onUpdateSettings }) => {
  const certificateRef = useRef<HTMLDivElement>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [previewSampleMode, setPreviewSampleMode] = useState(false);
  const [includeGuestId, setIncludeGuestId] = useState(
    appData.settings.includeGuestIdOnCertificate ?? true
  );

  const startingTotal = calculateTotalPrayers(appData.startingBalances);
  const remainingTotal = calculateTotalPrayers(appData.remainingBalances);
  const completedTotal = calculateTotalPrayers(appData.completedTotals);

  // Eligible only if user configured starting balance > 0 and remaining = 0
  const isEligible = startingTotal > 0 && remainingTotal === 0 && completedTotal >= startingTotal;

  // For sample mode or real mode:
  const displayCompleted: PrayerBalances = isEligible
    ? appData.completedTotals
    : { fajr: 365, dhuhr: 365, asr: 365, maghrib: 365, isha: 365 };

  const displayTotalPrayers = isEligible ? completedTotal : 365 * 5;
  const displayTotalRakats = isEligible ? calculateTotalRakats(appData.completedTotals) : 365 * 17;
  const completionDate = getArabicFormattedDate();

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    if (!certificateRef.current) return;
    setIsGeneratingPdf(true);

    try {
      const element = certificateRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
      });
      const imgData = canvas.toDataURL('image/png');

      // A4 Landscape format
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`شهادة_صلاتي_${appData.profile.displayName || 'إتمام_القضاء'}.pdf`);
    } catch (error) {
      console.error('فشل تصدير الشهادة إلى PDF:', error);
      alert('حدث خطأ أثناء تصدير ملف PDF، يمكنك استخدام زر الطباعة وحفظه كـ PDF.');
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Eligibility Banner */}
      <div className="bg-white dark:bg-stone-900 border border-emerald-800/20 dark:border-emerald-700/30 rounded-3xl p-5 shadow-sm text-stone-900 dark:text-stone-100">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-stone-950 flex items-center justify-center font-bold shadow-md">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold font-tajawal">شهادات إبراء الذمة والوفاء بالعهد</h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              توثيق تذكاري رسمي ومحفز عند تصفير رصيد الصلوات الفائتة
            </p>
          </div>
        </div>

        {/* Eligibility Status */}
        {isEligible ? (
          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-400 dark:border-emerald-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <div>
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 block">
                  مبارك لك! لقد استحققت شهادة إتمام قضاء الصلوات المسجلة
                </span>
                <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  تم تصفير الرصيد المسجل في ذمتك بالكامل ({completedTotal} صلاة).
                </span>
              </div>
            </div>
            <span className="px-3 py-1 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-xs">
              متاحة للتحميل
            </span>
          </div>
        ) : (
          <div className="p-3.5 rounded-2xl bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Lock className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <div>
                <span className="text-xs font-bold text-stone-800 dark:text-stone-200 block">
                  الشهادة الرسمية مغلقة حتى تصفير كامل الرصيد المسجل
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  متبقي في ذمتك: <span className="font-bold text-amber-600 dark:text-amber-400">{remainingTotal} صلاة</span>. واصل العزم والاجتهاد!
                </span>
              </div>
            </div>

            <button
              onClick={() => setPreviewSampleMode(!previewSampleMode)}
              className="text-xs font-bold px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-stone-950 shadow-xs transition cursor-pointer flex items-center gap-1.5 shrink-0"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{previewSampleMode ? 'إخفاء المعاينة' : 'معاينة النموذج التوضيحي'}</span>
            </button>
          </div>
        )}

        {/* Options */}
        <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includeGuestId}
              onChange={(e) => {
                setIncludeGuestId(e.target.checked);
                onUpdateSettings({ ...appData.settings, includeGuestIdOnCertificate: e.target.checked });
              }}
              className="w-4 h-4 accent-emerald-700 rounded"
            />
            <span className="text-stone-700 dark:text-stone-300 font-medium">
              تضمين معرّف الضيف المحلي (Guest ID) في الشهادة
            </span>
          </label>

          <div className="flex items-center gap-2 no-print">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>طباعة</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-4 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-amber-200 text-xs font-bold flex items-center gap-1.5 transition shadow-sm cursor-pointer disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span>{isGeneratingPdf ? 'جاري التصدير...' : 'تحميل PDF'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Printable / Viewable Certificate Frame */}
      <div className="overflow-x-auto pb-4">
        <div
          ref={certificateRef}
          className="certificate-frame min-w-[760px] bg-white text-stone-900 rounded-3xl p-8 border-8 border-double border-amber-500/80 shadow-2xl relative select-none"
          style={{
            backgroundImage:
              'radial-gradient(circle at 50% 50%, rgba(212, 175, 55, 0.04) 0%, transparent 80%)',
          }}
        >
          {/* Islamic Geometric Corner Accents */}
          <div className="absolute top-3 right-3 text-amber-500/40 font-amiri text-2xl select-none">
            ۞
          </div>
          <div className="absolute top-3 left-3 text-amber-500/40 font-amiri text-2xl select-none">
            ۞
          </div>
          <div className="absolute bottom-3 right-3 text-amber-500/40 font-amiri text-2xl select-none">
            ۞
          </div>
          <div className="absolute bottom-3 left-3 text-amber-500/40 font-amiri text-2xl select-none">
            ۞
          </div>

          {/* Sample watermark if not completed yet */}
          {!isEligible && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
              <span className="text-5xl font-black text-amber-500/15 rotate-[-20deg] select-none uppercase tracking-widest border-4 border-dashed border-amber-500/20 px-8 py-3 rounded-2xl">
                نموذج توضيحي • SAMPLE PREVIEW
              </span>
            </div>
          )}

          {/* Certificate Inner Content */}
          <div className="border border-amber-400/50 rounded-2xl p-6 text-center bg-stone-50/50">
            {/* Header: Logo and Basmala */}
            <div className="flex flex-col items-center mb-3">
              <img
                src="/assets/aistudio/1792715656850_9e02955c.jpg"
                alt="شعار صلاتي"
                className="w-16 h-16 rounded-2xl ring-2 ring-amber-400 shadow mb-2 object-cover"
              />
              <p className="font-amiri text-sm text-emerald-900 font-bold tracking-wide">
                بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
              </p>
              <p className="font-amiri text-xs text-amber-800 mt-0.5">
                «وَأَقِمِ الصَّلَاةَ طَرَفَيِ النَّهَارِ وَزُلَفًا مِّنَ اللَّيْلِ ۚ إِنَّ الْحَسَنَاتِ يُذْهِبْنَ السَّيِّئَاتِ»
              </p>
            </div>

            {/* Certificate Title */}
            <div className="my-4">
              <h1 className="text-2xl font-black text-emerald-950 font-amiri tracking-wide border-b-2 border-amber-400 pb-2 inline-block px-6">
                شهادة إتمام قضاء الصلوات المسجلة
              </h1>
            </div>

            {/* Certificate Body Text */}
            <p className="text-xs text-stone-700 leading-relaxed max-w-xl mx-auto mb-4">
              يشهد تطبيق <span className="font-bold text-emerald-900">«صلاتي | قضاء ما في الذمة»</span> بأن الأخ / الأخت الفاضل(ة):
            </p>

            <div className="my-3 py-1.5 px-6 rounded-xl bg-gradient-to-r from-emerald-50 via-amber-50 to-emerald-50 border border-amber-300 inline-block">
              <span className="text-xl font-black text-emerald-900 font-tajawal">
                {appData.profile.displayName || 'فاعل خير'}
              </span>
              {appData.profile.nickname && (
                <span className="text-xs text-stone-500 mr-2">({appData.profile.nickname})</span>
              )}
            </div>

            {includeGuestId && (
              <p className="text-[10px] text-stone-500 mt-1">
                معرف الضيف المحلي: <span className="font-mono font-bold text-amber-700" dir="ltr">{appData.profile.guestId}</span>
              </p>
            )}

            <p className="text-xs text-stone-700 leading-relaxed max-w-xl mx-auto my-3">
              قد أتمّ بفضل الله وتوفيقه قضاء جميع الصلوات الخمس المفروضة المسجلة في رصيد ذمته بتفاصيلها التالية:
            </p>

            {/* Prayer Breakdown Grid in Certificate */}
            <div className="grid grid-cols-5 gap-2 my-4 max-w-xl mx-auto text-center">
              {(['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const).map((p) => (
                <div key={p} className="p-2 rounded-xl bg-white border border-amber-300 shadow-xs">
                  <span className="text-[11px] font-bold text-emerald-900 block">{PRAYER_NAMES[p]}</span>
                  <span className="text-sm font-black text-amber-700 block my-0.5">
                    {displayCompleted[p].toLocaleString('ar-SA')}
                  </span>
                  <span className="text-[9px] text-stone-500 block">
                    {displayCompleted[p] * STANDARD_RAKATS[p]} ركعة
                  </span>
                </div>
              ))}
            </div>

            {/* Overall totals */}
            <div className="bg-emerald-900 text-amber-200 rounded-xl p-2.5 max-w-lg mx-auto flex items-center justify-around text-xs font-bold mb-4">
              <span>إجمالي الصلوات المنجزة: {displayTotalPrayers.toLocaleString('ar-SA')} صلاة</span>
              <span>•</span>
              <span>إجمالي الركعات المقابلة: {displayTotalRakats.toLocaleString('ar-SA')} ركعة تقريبية</span>
            </div>

            {/* Official Disclaimer */}
            <p className="text-[10px] text-stone-500 max-w-lg mx-auto italic mb-6">
              * تنويه: هذه الشهادة وثيقة تذكارية رقمية صادرة من التطبيق بناءً على المدخلات الشخصية للمستخدم لتشجيعه وتوثيق اجتهاده، وليست صكاً أو فتوى شرعية مبرئة للذمة خارج نطاق تسجيلاته.
            </p>

            {/* Footer with Signatures & Credits */}
            <div className="pt-4 border-t border-amber-300/80 flex items-end justify-between text-xs text-stone-700 max-w-2xl mx-auto">
              <div className="text-right">
                <span className="text-[11px] text-stone-500 block">تاريخ الإتمام / الإصدار:</span>
                <span className="font-bold text-stone-900">{completionDate}</span>
              </div>

              <div className="text-center">
                <span className="text-[11px] font-bold text-emerald-900 block">تطبيق صلاتي | قضاء ما في الذمة</span>
                <span className="text-[10px] text-stone-500">تطوير: أباالفضل نهاد حسن</span>
              </div>

              <div className="text-left">
                <span className="text-[11px] text-stone-500 block">برعاية وتوجيه:</span>
                <span className="font-bold text-emerald-900">شبكة المنتظر</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
